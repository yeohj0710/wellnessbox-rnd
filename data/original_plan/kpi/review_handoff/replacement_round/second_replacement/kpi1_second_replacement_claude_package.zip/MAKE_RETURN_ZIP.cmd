@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -LiteralPath 'kpi1_response.json','reviewer_identity_selection.json' -DestinationPath 'kpi1_second_replacement_completed.zip' -Force"
